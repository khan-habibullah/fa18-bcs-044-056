from django.db import models
from .catagory import Catagory
class Product(models.Model):
    product_name=models.CharField(max_length=30)
    price=models.IntegerField(default=0)
    catagory=models.ForeignKey(Catagory , on_delete=models.CASCADE)
    desc=models.CharField(max_length=300)
    pub_date=models.DateField()
    image=models.ImageField(upload_to="shop/images", default="")

    def __str__(self):
        return self.product_name
    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in=ids)
    @staticmethod
    def get_all_products():
        return Product.objects.all()
    @staticmethod
    def get_all_products_by_catagoryid(catagory_id):
        if catagory_id:
            return Product.objects.filter(catagory = catagory_id)
        else:
            return Product.get_all_products();