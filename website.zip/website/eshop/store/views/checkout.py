from django.shortcuts import render,redirect
from django.views import View

class Checkout(View):
    def get(self,request):
        return render(request,'shop/checkout.html')