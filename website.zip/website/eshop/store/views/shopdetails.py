from django.shortcuts import render,redirect
from django.views import View

class Shopdetails(View):
    def get(self,request):
        return render(request,'shop/shopdetails.html')