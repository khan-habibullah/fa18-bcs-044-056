from django.contrib import admin
from .models.product import Product
from .models.catagory import Catagory
from .models.customer import Customers
class adminproduct(admin.ModelAdmin):
    list_display = ['product_name','price','catagory']
admin.site.register(Product, adminproduct)
class admincatagory(admin.ModelAdmin):
    list_display=['name']
admin.site.register(Catagory,admincatagory)
admin.site.register(Customers)