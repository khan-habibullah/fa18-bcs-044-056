from django.urls import path
from. views import home,about,cart,checkout,contact,services,shop,shopdetails,basic
from .import views
urlpatterns = [
    path("", home.Index.as_view(), name="eshop"),
    path("about/", about.About.as_view(), name="about"),
    path("cart/", cart.Cart.as_view(), name="cart"),
    path("checkout/", checkout.Checkout.as_view(), name="checkout"),
    path("contact/", contact.Contact.as_view(), name="contact"),
    path("services/", services.Services.as_view(), name="services"),
    path("shop/", shop.Shop.as_view(), name="shop"),
    path("shopdetails/", shopdetails.Shopdetails.as_view(), name="shopdetails"),
    path("basic/", basic.Basic.as_view(), name="basic")
    ]